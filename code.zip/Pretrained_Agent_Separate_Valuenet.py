# agent.py
import torch
import torch.nn as nn
import torch.nn.functional as F
from sympy.physics.quantum.density import entropy
from torch.distributions import Categorical

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

class PolicyNetwork(nn.Module):
    def __init__(self, input_dim, output_dim, hidden_dim=32):
        super().__init__()
        self.fc1 = nn.Linear(input_dim, hidden_dim)
        self.fc2 = nn.Linear(hidden_dim, hidden_dim)
        self.policy_head = nn.Linear(hidden_dim, output_dim)

    def forward(self, x):
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        return self.policy_head(x)

class ValueNetwork(nn.Module):
    def __init__(self, input_dim, hidden_dim=128):
        super().__init__()
        self.fc1 = nn.Linear(input_dim, hidden_dim)
        self.value_head = nn.Linear(hidden_dim, 1)

    def forward(self, x):
        x = F.relu(self.fc1(x))
        return self.value_head(x)

class RLAgent:
    def __init__(self, obs_dim, act_dim, lr=1e-3, gamma=0.99, use_opponent_model=False, opponent_model=None):
        self.gamma = gamma
        self.use_opponent_model = use_opponent_model
        self.opponent_model = opponent_model
        self.policy = PolicyNetwork(obs_dim, act_dim).to(DEVICE)
        self.value = ValueNetwork(obs_dim).to(DEVICE)
        self.policy_optimizer = torch.optim.Adam(self.policy.parameters(), lr=lr)
        self.value_optimizer = torch.optim.Adam(self.value.parameters(), lr=lr * 0.2)

    def get_action(self, obs, mask):
        obs = torch.tensor(obs, dtype=torch.float32, device=DEVICE).unsqueeze(0)
        logits = self.policy(obs)
        values = self.value(obs)
        mask_tensor = torch.tensor(mask, dtype=torch.bool, device=DEVICE)
        # Mask logits BEFORE softmax
        masked_logits = logits.masked_fill(~mask_tensor, -1e9)
        probs = torch.softmax(masked_logits, dim=-1).squeeze()
        # === DEBUGGING: detect NaN ===
        if torch.isnan(probs).any():
            print("\n====== DEBUG INFO ======")
            print("obs:", obs)
            print("raw logits:", logits)
            print("mask:", mask)
            print("masked logits:", masked_logits)
            print("probs BEFORE softmax:", logits)
            print("probs AFTER softmax:", probs)
            print("========================\n")
            raise RuntimeError("NaN detected in probs — see debug info above.")
        dist = Categorical(probs)
        action = dist.sample()
        entropy = dist.entropy()
        return action.item(), dist.log_prob(action), values.squeeze(), entropy.squeeze()

    def update_policy_value(self, log_probs, rewards, values, entropies, method="REINFORCE"):
        assert method in ["REINFORCE", "A2C"]
        if method == "REINFORCE":
            ## Use MC advantage (V(s)- V_hat(s)) to update policy net, use MC return to update value net.
            returns, G = [], 0
            for r in reversed(rewards):
                G = r + self.gamma * G
                returns.insert(0, G)
            returns = torch.tensor(returns, dtype=torch.float32, device=DEVICE)[1:]
            log_probs = torch.stack(log_probs)
            values = torch.stack(values)
            entropies = torch.stack(entropies)
            advantages = returns - values.detach()  # baseline
            policy_loss = -(log_probs * advantages).mean() - 0.01 * entropies.mean()
            value_loss = F.mse_loss(values, returns)
        elif method == "A2C":
            ## Use one-step TD error(r(s,a)+gamma V(s')-V(s)) to update policy net, use one-step TD-Target to update value net
            rewards = torch.tensor(rewards[1:], dtype=torch.float32, device=DEVICE)
            log_probs = torch.stack(log_probs)
            values = torch.stack(values)
            next_values = torch.cat([values[1:], torch.tensor([0.0], device=DEVICE)])
            entropies = torch.stack(entropies)

            td_target = rewards + self.gamma * next_values
            td_delta = td_target - values
            policy_loss = -(log_probs * td_delta.detach()).mean()- 0.01 * entropies.mean()
            value_loss = F.mse_loss(values, td_target)

        self.policy_optimizer.zero_grad()
        policy_loss.backward()
        self.policy_optimizer.step()

        self.value_optimizer.zero_grad()
        value_loss.backward()
        self.value_optimizer.step()